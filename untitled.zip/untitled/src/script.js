// 12問の質問データ
const questions = [
  {
    q: "ぬいとお出かけするとき、どんなスタイルが多い？",
    a: [
      { text: "バッグの見える位置やポーチに入れて連れて行く！", type: "happy" },
      { text: "景色やごはん写真を撮るときだけそっと出す", type: "cool" },
      { text: "汚れたら心配だから、大切におうちで留守番してもらう", type: "serious" },
      { text: "出かける前「行ってくるね」と声をかけるスタイル", type: "cute" }
    ]
  },
  {
    q: "旅行や長距離移動のとき、ぬいはどうする？",
    a: [
      { text: "もちろん一緒！移動中も手元に置いておく", type: "happy" },
      { text: "旅先での記念撮影用にメインの子を1人厳選", type: "cool" },
      { text: "お留守番してもらい、帰ってきたらお土産話をする", type: "serious" },
      { text: "ベッドをきれいに整えて「おうちを守ってね」と頼む", type: "dreamy" }
    ]
  },
  {
    q: "休日、お部屋で過ごすときぬいはどこにいる？",
    a: [
      { text: "いつも膝の上か、触れ合える距離にいる", type: "cute" },
      { text: "机の上から作業や勉強をじっと見守っている", type: "cool" },
      { text: "窓辺やおしゃれな棚の上でおしゃれに鎮座", type: "dreamy" },
      { text: "おでかけ用バッグの中で出番を待っている", type: "happy" }
    ]
  },
  {
    q: "疲れて家に帰ってきた時、ぬいに求めるのは？",
    a: [
      { text: "ただ静かに抱きしめてもらう至福の癒やし", type: "cute" },
      { text: "見ているだけでフッと肩の力が抜ける安心感", type: "dreamy" },
      { text: "「今日もお疲れ！」と笑顔で出迎えてくれるパワー", type: "happy" },
      { text: "ポーズをつけて遊んだりして気分転換させてくれる元気", type: "serious" }
    ]
  },
  {
    q: "ぬいの表情や全体的な雰囲気は？",
    a: [
      { text: "おだやかで優しい、眠そうな表情", type: "cute" },
      { text: "ぽかんとしていて何を考えているか分からない表情", type: "dreamy" },
      { text: "にっこり笑顔でやる気に満ちあふれた表情", type: "happy" },
      { text: "キリッとしていて自信たっぷりな表情", type: "cool" }
    ]
  },
  {
    q: "落ち込んだ時、ぬいにどう接する？",
    a: [
      { text: "顔をうずめて無言でエネルギーを補給する", type: "cute" },
      { text: "頭や背中を撫でながら気持ちを落ち着かせる", type: "serious" },
      { text: "愚痴や今日あったことを全部聞いてもらう", type: "happy" },
      { text: "もちもち撫でたり、色々なポーズをとってもらう", type: "serious" }
    ]
  },
  {
    q: "ぬいを一言で表すならどんな存在？",
    a: [
      { text: "何でも知っている、対等で一番の親友", type: "serious" },
      { text: "弟や妹のように世話を焼きたくなる存在", type: "cute" },
      { text: "お部屋の平和と我が家を守る頼もしい守護神", type: "serious" },
      { text: "長年寄り添ってくれた兄や姉のような存在", type: "cool" }
    ]
  },
  {
    q: "ぬいを置く部屋の「定位置」はどこ？",
    a: [
      { text: "枕元やベッドのすぐとなり", type: "cute" },
      { text: "デスクの上や一番よく使う椅子の背もたれ", type: "cool" },
      { text: "部屋全体が見渡せる高い棚の上", type: "serious" },
      { text: "他のぬいたちをまとめる中央の特等席", type: "happy" }
    ]
  },
  {
    q: "ぬいに対して普段一番思うことは？",
    a: [
      { text: "「いつも隣にいてくれてありがとう」", type: "cute" },
      { text: "「一緒に色んな思い出を作っていこうね」", type: "happy" },
      { text: "「このお部屋を守ってくれてて助かるよ」", type: "serious" },
      { text: "「あなたがいてくれるだけで家中が平和」", type: "dreamy" }
    ]
  },
  {
    q: "ぬいの見た目やデザインの好み・特徴は？",
    a: [
      { text: "ちょっと個性的でシュール、味わい深いビジュアル", type: "dreamy" },
      { text: "手作りの服やアレンジ小物が似合うおしゃべりな見た目", type: "happy" },
      { text: "王道の可愛さ！ふわふわでクラシックなデザイン", type: "cute" },
      { text: "シンプルで洗練された、誰が見ても愛される姿", type: "cool" }
    ]
  },
  {
    q: "ぬいに着せ替えやアクセサリーをつけるなら？",
    a: [
      { text: "個性派ファッションや帽子でアレンジしてあげたい！", type: "dreamy" },
      { text: "季節ごとにイベント衣装をしっかり着せ替えたい！", type: "happy" },
      { text: "シンプルなリボンやバンダナひとつで十分可愛い！", type: "serious" },
      { text: "素材そのままの姿が一番好きなので何もつけない", type: "cool" }
    ]
  },
  {
    q: "このぬいをお迎えしたときの「決め手」は？",
    a: [
      { text: "他にはない独特の表情やクセになる存在感", type: "dreamy" },
      { text: "「なんだか目が合ってしまった」という運命的なインスピレーション", type: "happy" },
      { text: "ひと目でキュンとくる完璧なバランスの可愛さ", type: "cute" },
      { text: "触り心地の良さと、包容力を感じる安心感", type: "serious" }
    ]
  }
];

// 5大タイプとサブカテゴリデータ
const typeDetails = {
  cute: {
    name: "【🎀キュートタイプ】",
    sub: [
      {
        subname:"アイドル系",
        title: "みんなのアイドル系キュートぬい",
        personality: "どこにいてもパッと目を惹く愛らしさで、みんなの視線を独り占めするスター気質なぬいぐるみです。",
        aruaru: "写真を撮ると、なぜか一番カメラ目線が決まっている。",
        quote: "「ぼくを見て！今日も可愛いって言って？」"
      },
      {
        subname:"癒し系",
        title: "癒し系キュートぬい",
        personality: "見ているだけでふにゃっと心が緩む、圧倒的な癒やしオーラを放つお部屋の必須アイテム。",
        aruaru: "疲れて帰ってきたときに目が合うと、一瞬でHPが全回復する。",
        quote: "「お疲れ様。なでなでしてくれてもいいよ？」"
      },
      {
        subName: "心優しい",
        title: "心優しいキュートぬい",
        personality: "持ち主の機嫌をそっと察して寄り添ってくれる、ピュアで優しい心を持った天使のような相棒。",
        aruaru: "落ち込んでいるとき、一番近くで無言の優しさを発揮する。",
        quote: "「泣き虫さんは、ぼくがぎゅーってしてあげるね」"
      }
    ]
  },
  cool: {
    name: "【👓クールな知性派タイプ】",
    sub: [
      {
        subName: "頭脳派",
        title: "頭脳派クールぬい",
        personality: "デスクの上で難しそうな顔をしながら、あなたの勉強や仕事をスマートにサポートしてくれる知性派。",
        aruaru: "パソコンの横にいると、しごでき感が一気に増す。",
        quote: "「その調子！君なら次もできる！」"
      },
      {
        subName: "我が道を行く",
        title: "我が道を行くクールぬい",
        personality: "周囲に流されず、自分の好きなポーズと美学を貫き通す孤高のマイペース・アーティスト。",
        aruaru: "気づくと部屋の隅っこで渋い顔をしてこっちを見ている。",
        quote: "「邪魔をするな。…なんてね、冗談」"
      },
      {
        subName: "実はお茶目",
        title: "実はお茶目なクールぬい",
        personality: "一見クールで近寄りがたい雰囲気だけど、ふとした瞬間に抜けた一面を見せる愛され枠。",
        aruaru: "カッコつけた直後にゴロンと転がりがち。",
        quote: "「いまのは…見なかったことにして」"
      }
    ]
  },
  happy: {
    name: "【🎉ハッピータイプ】",
    sub: [
      {
        subName: "ポジティブ",
        title: "ポジティブハッピーぬい",
        personality: "どんなにどん底な気分でも「なんとかなるさ！」と強制的に笑わせてくれる太陽のようなお気楽エネルギーの塊。",
        aruaru: "部屋に置いてあるだけで、空気がパッと明るく華やかになる。",
        quote: "「人生楽しんだもん勝ち！いぇーい！」"
      },
      {
        subName: "フッ軽",
        title: "フッ軽おでかけハッピーぬい",
        personality: "「どこ行くの？僕も連れてって！」とバッグの中で常にスタンバイしている、お出かけ大好きアクティブ派。",
        aruaru: "お出かけ用のカバンを変えると、すかさず中に入り込んでいる。",
        quote: "「準備OK？さあ、今日の冒険に出発だー！」"
      },
      {
        subName: "パーティー大好き",
        title: "パーティー大好きハッピーぬい",
        personality: "楽しいことが大好きで、お部屋の中にいつもワクワクしたお祭りムードを運んできてくれる盛り上げ役。",
        aruaru: "イベントの時期になると、誰よりもはしゃいでいるように見える。",
        quote: "「今日も楽しいこと間違いなし！騒ごうぜ！」"
      }
    ]
  },
  serious: {
    name: "【☘️しっかり者タイプ】",
    sub: [
      {
        subName: "さびしがり",
        title: "さびしがりなしっかり者ぬい",
        personality: "普段はしっかりお留守番しているけれど、あなたが帰ってきた途端に甘えんぼモードが全開になる健気な子。",
        aruaru: "お留守番を頑張った後の「おかえり」の圧がちょっと強い。",
        quote: "「ずっと待ってたんだよ…寂しかったんだからね」"
      },
      {
        subName: "がんばり屋さん",
        title: "がんばり屋さんなしっかり者ぬい",
        personality: "あなたの頑張りを一番近くでずっと見ていて、陰ながらそっと背中を押し続けてくれる努力家の相棒。",
        aruaru: "デスクの上で一緒に夜更かしにつきあってくれる戦友。",
        quote: "「君なら絶対できるよ。ぼくがついてるから！」"
      },
      {
        subName: "気配り上手",
        title: "気配り上手なしっかり者ぬい",
        personality: "部屋の治安とあなたのメンタルを常に完璧なバランスで保ってくれる、一家に一匹欲しいスーパー有能執事。",
        aruaru: "部屋の乱れや生活リズムの乱れを、その佇まいで静かに正してくる。",
        quote: "「体調管理はしっかりしてくださいね。お茶にしますか？」"
      }
    ]
  },
  dreamy: {
    name: "【🌙ドリーミータイプ】",
    sub: [
      {
        subName: "個性派",
        title: "個性派ドリーミーぬい",
        personality: "どこかシュールで不思議な魅力を放ち、周りの常識にとらわれない唯一無二の世界観を持ったクセ強マイペース。",
        aruaru: "友達に紹介すると「それ、どこで買ったの…？」と高確率で聞かれる。",
        quote: "「ねえ、あっちの星までお散歩に行かない？」"
      },
      {
        subName: "マイワールド",
        title: "マイワールド全開ドリーミーぬい",
        personality: "常に自分の世界に浸っていて、話しかけるとフワフワした返事が返ってきそうな独自の空間の持ち主。",
        aruaru: "ぼーっと見つめていると、自分も現実逃避できちゃう不思議な魔力がある。",
        quote: "「ふふ、今すごく面白い夢を見てたんだぁ」"
      },
      {
        subName: "のんびり",
        title: "のんびりマイペース・ドリーミーぬい",
        personality: "世間のスピードなんてお構いなし！自分のペースでまったりと生きる、見ているだけで癒やされるスローライフの達人。",
        aruaru: "いつ見ても同じ場所で同じようにのんびりダラダラしている。",
        quote: "「急がなくても、いいことあるよ。お昼寝しよう…」"
      }
    ]
  }
};

let currentQuestion = 0;
let scores = { cute: 0, cool: 0, happy: 0, serious: 0, dreamy: 0 };

function startQuiz() {
  currentQuestion = 0;
  scores = { cute: 0, cool: 0, happy: 0, serious: 0, dreamy: 0 };
  document.getElementById("start-screen").style.display = "none";
  document.getElementById("quiz-screen").style.display = "block";
  showQuestion();
}

function showQuestion() {
  const q = questions[currentQuestion];
  document.getElementById("question-number").innerText = `Q${currentQuestion + 1} / ${questions.length}`;
  document.getElementById("question-text").innerText = q.q;
  
  const progressPercent = (currentQuestion / questions.length) * 100;
  document.getElementById("progress").style.width = `${progressPercent}%`;

  const choicesContainer = document.getElementById("choices-container");
  choicesContainer.innerHTML = "";

  q.a.forEach(choice => {
    const btn = document.createElement("button");
    btn.className = "choice-btn";
    btn.innerText = choice.text;
    btn.onclick = () => selectChoice(choice.type);
    choicesContainer.appendChild(btn);
  });
}

function selectChoice(type) {
  scores[type]++;
  currentQuestion++;

  if (currentQuestion < questions.length) {
    showQuestion();
  } else {
    showResult();
  }
}

function showResult() {
  document.getElementById("quiz-screen").style.display = "none";
  document.getElementById("result-screen").style.display = "block";

  // 一番ポイントが高いメインタイプを決定
  let bestType = "cute";
  let maxScore = -1;
  for (let key in scores) {
    if (scores[key] > maxScore) {
      maxScore = scores[key];
      bestType = key;
    }
  }

  // メーター計算（割合）
  const totalScore = Object.values(scores).reduce((a, b) => a + b, 0) || 1;
  const getPct = (typeKey) => Math.round((scores[typeKey] / totalScore) * 100);

  const cutePct = getPct("cute");
  const coolPct = getPct("cool");
  const happyPct = getPct("happy");
  const seriousPct = getPct("serious");
  const dreamyPct = getPct("dreamy");

  document.getElementById("meter-cute").style.width = `${cutePct}%`;
  document.getElementById("meter-cool").style.width = `${coolPct}%`;
  document.getElementById("meter-happy").style.width = `${happyPct}%`;
  document.getElementById("meter-serious").style.width = `${seriousPct}%`;
  document.getElementById("meter-dreamy").style.width = `${dreamyPct}%`;

  document.getElementById("label-cute").innerText = `${cutePct}%`;
  document.getElementById("label-cool").innerText = `${coolPct}%`;
  document.getElementById("label-happy").innerText = `${happyPct}%`;
  document.getElementById("label-serious").innerText = `${seriousPct}%`;
  document.getElementById("label-dreamy").innerText = `${dreamyPct}%`;

  // サブカテゴリからランダムに1つ選んで表示
  const typeObj = typeDetails[bestType];
  const randomSub = typeObj.sub[Math.floor(Math.random() * typeObj.sub.length)];

  // ちゃんとタイトルが代入されるように修正
  document.getElementById("type-code").innerText = `${typeObj.name} 【${randomSub.subName}】`;
  document.getElementById("type-title").innerText = randomSub.title;

  document.getElementById("comment-personality").innerText = randomSub.personality;
  document.getElementById("comment-aruaru").innerText = randomSub.aruaru;
  document.getElementById("comment-quote").innerText = randomSub.quote;
}

function resetQuiz() {
  document.getElementById("result-screen").style.display = "none";
  document.getElementById("start-screen").style.display = "block";
}
